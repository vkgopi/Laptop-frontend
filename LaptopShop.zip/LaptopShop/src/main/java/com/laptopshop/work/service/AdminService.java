package com.laptopshop.work.service;

import java.util.List;

import com.laptopshop.work.entity.Admin;

public interface AdminService {
	//update admin
	public Admin updateAdmin(Admin admin);
	
	//getAdminById
	public Admin getAdminId(long id);
	
	//getAllAdminInfo
	public List<Admin> getAllAdmin();
}
