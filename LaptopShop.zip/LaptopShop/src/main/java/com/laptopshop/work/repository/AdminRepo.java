package com.laptopshop.work.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.laptopshop.work.entity.Admin;

public interface AdminRepo extends JpaRepository<Admin, Long>{

}