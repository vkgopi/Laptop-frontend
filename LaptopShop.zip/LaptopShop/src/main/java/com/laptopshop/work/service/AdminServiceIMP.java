package com.laptopshop.work.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.laptopshop.work.entity.Admin;
import com.laptopshop.work.repository.AdminRepo;

@Service
public class AdminServiceIMP implements AdminService{
	private AdminRepo repository;
	
	public AdminServiceIMP(AdminRepo repository) {
		super();
		this.repository = repository;
	}

	@Override
	public Admin updateAdmin (Admin admin) {
		// TODO Auto-generated method stub	
		return repository.save(admin);
	}

	@Override
	public Admin getAdminId(long id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}

	@Override
	public List<Admin> getAllAdmin() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

}
